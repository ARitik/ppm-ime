package controller;

import java.io.IOException;

import jdk.jshell.spi.ExecutionControl;
import model.ImageOperationsBasicPlus;

/**
 * An interface that represents the image Commands.
 */
interface ImageCommand {
    /**
     * The method executes the relevant method in the model.
     *
     * @param model model object
     * @throws IOException
     * @throws ExecutionControl.NotImplementedException
     */
    void execute(ImageOperationsBasicPlus model) throws IOException, ExecutionControl.NotImplementedException;
}
